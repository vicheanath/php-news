<section id="footer">
    <div class="container">
        <div class="row">
            <!-- Adress -->
            <div class="col-md-4 address">
                <h2>អស័យដ្ជាន</h2>
                <p>ភ្នំពេញ</p>
            </div>
            <!-- Info -->
            <div class="col-md-4 info">
                <h2>អំពីយើង</h2>
                <p>Vrepor News</p>
            </div>
            <!-- Contuct -->
            <div class="col-md-4 contuct">
                <h2>ទំនាក់ទំនង</h2>
                <ul>
                    <li><a target="_blank" href="https://www.facebook.com/3am.midnight" class="facebook-color"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="" class="youtube-color"><i class="fab fa-youtube"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>