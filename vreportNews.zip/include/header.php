<!doctype html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <meta name="google-site-verification" content="jH9JpiUPp7RPzRniFzEwQRnsK61Uz5GNKT990xohEPQ" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <!-- Style -->
    <link rel="stylesheet" href="<?php echo BASE_URL ?>assete/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>assete/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>assete/css/mobile.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>assete/css/responsive.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>assete/css/color.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>assete/css/footer.css">
    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Dangrek&family=Kantumruy:wght@300;400;700&family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>admin/assets/css/fontawesome-free-5.11.2-web/css/all.min.css">
    <!-- Slideder -->
    <!-- JS li -->
    <script src="<?php echo BASE_URL ?>assete/js/jquery-3.4.1.js"></script>
    <script src="<?php echo BASE_URL ?>assete/js/javascript.js"></script>
    <script>
     var url = '<?php echo BASE_URL ?>';
    </script>
    <script src="<?php echo BASE_URL ?>assete/js/fuction.js"></script>
    <!-- Facebook -->
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v6.0&appId=379994899221403&autoLogAppEvents=1"></script>