<?php
$img=$_POST['img'];
unlink('../img/product/'.$img);
?>